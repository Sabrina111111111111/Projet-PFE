const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
require("dotenv").config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());
app.use(cors({
  origin: 'http://adresse-ip-frontend:port', // Remplacez par l'URL de votre frontend
  credentials: true // Si vous utilisez des cookies/sessions
}));


// Connexion MongoDB
mongoose.connect(process.env.MONGODB_URI)
  .then(() => console.log("✅ Connecté à MongoDB"))
  .catch(err => console.error("❌ Erreur MongoDB:", err));

// Routes
app.use("/api/audits", require("./routes/auditRoutes"));


// Démarrer le serveur
const PORT = process.env.PORT || 5000;
app.listen(PORT,'192.168.1.3', () => {
  console.log(`🚀 API backend sur http://localhost:${PORT}`);
});
