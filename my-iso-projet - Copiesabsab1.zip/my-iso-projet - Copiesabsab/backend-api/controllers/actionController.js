const CorrectiveAction = require('../models/CorrectiveAction');

// Cr�er une action corrective
exports.createCorrectiveAction = async (req, res) => {
  const { description, dueDate, controlId } = req.body;

  try {
    const newAction = new CorrectiveAction({ description, dueDate, complianceControl: controlId });
    await newAction.save();
    res.status(201).json({ message: 'Action corrective cr��e avec succ�s.', action: newAction });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la cr�ation de l\'action corrective.', error });
  }
};

// R�cup�rer toutes les actions correctives d'un contr�le de conformit�
exports.getCorrectiveActions = async (req, res) => {
  const { controlId } = req.query;

  try {
    const actions = await CorrectiveAction.find({ complianceControl: controlId });
    res.json(actions);
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la r�cup�ration des actions correctives.', error });
  }
};