const User = require('../models/users');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// @desc    Enregistrer un nouvel utilisateur
// @route   POST /api/users/register
// @access  Public
exports.registerUser = async (req, res) => {
  const { username, email, password } = req.body;

  try {
    // Vérifier si l'utilisateur existe déjà
    const userExists = await User.findOne({ email });
    if (userExists) {
      return res.status(400).json({ message: 'Cet email est déjà utilisé.' });
    }

    // Créer l'utilisateur
    const user = await User.create({
      username,
      email,
      passwordHash: password // Serra hashé automatiquement par le pre-save hook
    });

    // Générer le token JWT
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { 
      expiresIn: '30d' 
    });

    res.status(201).json({
      _id: user._id,
      username: user.username,
      email: user.email,
      role: user.role,
      token
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Erreur lors de l\'enregistrement de l\'utilisateur.',
      error: error.message 
    });
  }
};

// @desc    Connecter un utilisateur
// @route   POST /api/users/login
// @access  Public
exports.loginUser = async (req, res) => {
  const { email, password } = req.body;

  try {
    const user = await User.findOne({ email });

    // Vérifier l'utilisateur et le mot de passe
    if (user && (await bcrypt.compare(password, user.passwordHash))) {
      const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, {
        expiresIn: '30d'
      });

      res.json({
        _id: user._id,
        username: user.username,
        email: user.email,
        role: user.role,
        token
      });
    } else {
      res.status(401).json({ message: 'Email ou mot de passe invalide.' });
    }
  } catch (error) {
    res.status(500).json({ 
      message: 'Erreur lors de la connexion.',
      error: error.message 
    });
  }
};

// @desc    Récupérer le profil utilisateur
// @route   GET /api/users/me
// @access  Private
exports.getUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('-passwordHash');
    if (!user) {
      return res.status(404).json({ message: 'Utilisateur non trouvé.' });
    }
    res.status(200).json(user);
  } catch (error) {
    res.status(500).json({ 
      message: 'Erreur lors de la récupération du profil.',
      error: error.message 
    });
  }
};

// @desc    Mettre à jour le profil utilisateur
// @route   PUT /api/users/me
// @access  Private
exports.updateUserProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({ message: 'Utilisateur non trouvé.' });
    }

    user.username = req.body.username || user.username;
    user.email = req.body.email || user.email;

    if (req.body.password) {
      user.passwordHash = req.body.password; // Serra hashé automatiquement
    }

    const updatedUser = await user.save();

    res.json({
      _id: updatedUser._id,
      username: updatedUser.username,
      email: updatedUser.email,
      role: updatedUser.role
    });
  } catch (error) {
    res.status(500).json({ 
      message: 'Erreur lors de la mise à jour du profil.',
      error: error.message 
    });
  }
};