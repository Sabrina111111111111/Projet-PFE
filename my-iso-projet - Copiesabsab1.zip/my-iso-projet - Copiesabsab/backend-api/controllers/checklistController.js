const Checklist = require('../models/Checklist');

// Cr�er une nouvelle checklist
exports.createChecklist = async (req, res) => {
  const { name, createdBy, controls } = req.body;

  try {
    const newChecklist = new Checklist({ name, createdBy, controls });
    await newChecklist.save();
    res.status(201).json({ message: 'Checklist cr��e avec succ�s.', checklist: newChecklist });
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la cr�ation de la checklist.', error });
  }
};

// R�cup�rer toutes les checklists d'un utilisateur
exports.getChecklists = async (req, res) => {
  const { userId } = req.query;

  try {
    const checklists = await Checklist.find({ createdBy: userId });
    res.json(checklists);
  } catch (error) {
    res.status(500).json({ message: 'Erreur lors de la r�cup�ration des checklists.', error });
  }
};