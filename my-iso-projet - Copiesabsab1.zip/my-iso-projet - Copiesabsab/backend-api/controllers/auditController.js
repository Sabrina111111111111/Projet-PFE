const Audit = require('../models/Audit');
const logger = require('../utils/logger');
// Cr�er un nouvel audit
exports.createAudit = async (req, res) => {
    try {
        const { title, description } = req.body;
        const audit = new Audit({ title, description }); // Cr�ation d'un nouvel audit
        await audit.save(); // Sauvegarde dans la base de donn�es
        logger.info(`Audit cr��: ${audit._id}`);
        res.status(201).json(audit); // R�ponse avec l'audit cr��
    } catch (error) {
        logger.error('Erreur création audit:', error); // ✔️
        res.status(500).json({ message: error.message });
    }
};

// Obtenir la liste des audits
exports.getAudits = async (req, res) => {
    try {
        const audits = await Audit.find().populate('recommendations'); // R�cup�re tous les audits avec leurs recommandations
        res.status(200).json(audits); // R�ponse avec la liste des audits
    } catch (error) {
        res.status(500).json({ message: error.message }); // Gestion des erreurs
    }
};