const mongoose = require('mongoose');

const correctiveActionSchema = new mongoose.Schema({
  description: { type: String, required: true }, // Description de l'action corrective
  dueDate: { type: Date, required: true }, // Date d'�ch�ance
  status: { type: String, enum: ['en cours', 'termin�', 'en attente'], default: 'en cours' }, // Statut de l'action
  complianceControl: { type: mongoose.Schema.Types.ObjectId, ref: 'ComplianceControl', required: true } // Contr�le de conformit� associ�
});

module.exports = mongoose.model('CorrectiveAction', correctiveActionSchema);