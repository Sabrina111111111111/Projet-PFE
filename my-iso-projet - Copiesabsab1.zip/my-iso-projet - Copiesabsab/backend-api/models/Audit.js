const mongoose = require('mongoose');

// D�finition du sch�ma pour les audits
const AuditSchema = new mongoose.Schema({
    title: { type: String, required: true }, // Titre de l'audit
    description: { type: String, required: true }, // Description de l'audit
    status: { type: String, enum: ['En cours', 'Termin�', 'Non conforme'], default: 'En cours' }, // Statut de l'audit
    date: { type: Date, default: Date.now }, // Date de cr�ation de l'audit
    recommendations: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Recommendation' }] // R�f�rence aux recommandations associ�es
});

// Exportation du mod�le Audit
module.exports = mongoose.model('Audit', AuditSchema);