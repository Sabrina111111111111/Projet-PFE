const mongoose = require('mongoose');

const checklistSchema = new mongoose.Schema({
  name: { type: String, required: true }, // Nom de la checklist
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true }, // ID de l'utilisateur
  createdAt: { type: Date, default: Date.now }, // Date de cr�ation
  updatedAt: { type: Date, default: Date.now }, // Date de mise � jour
  controls: [ // Liste des contr�les inclus dans la checklist
    {
      reference: { type: String, required: true }, // R�f�rence du contr�le (exemple : A.5.1.1)
      description: { type: String, required: true }, // Description du contr�le
      notes: { type: String, default: '' }, // Notes personnalis�es
      status: { type: String, enum: ['conforme', 'non-conforme', 'en cours'], default: 'en cours' } // Statut du contr�le
    }
  ]
});

module.exports = mongoose.model('Checklist', checklistSchema);