const logSchema = new mongoose.Schema({
  action: { type: String, required: true }, // Ex: "POST /api/audits"
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  ip: String,
  details: Object,
  status: { type: String, enum: ['success', 'failed', 'warning'] }
}, { timestamps: true });