const express = require('express');
const actionController = require('../controllers/actionController');
const router = express.Router();

// Cr�er une action corrective
router.post('/', actionController.createCorrectiveAction);

// R�cup�rer toutes les actions correctives d'un contr�le de conformit�
router.get('/', actionController.getCorrectiveActions);

module.exports = router;