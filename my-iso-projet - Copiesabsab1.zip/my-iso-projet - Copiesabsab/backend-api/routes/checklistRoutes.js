const express = require('express');
const checklistController = require('../controllers/checklistController');
const router = express.Router();

// Cr�er une checklist
router.post('/', checklistController.createChecklist);

// R�cup�rer toutes les checklists d'un utilisateur
router.get('/', checklistController.getChecklists);

module.exports = router;