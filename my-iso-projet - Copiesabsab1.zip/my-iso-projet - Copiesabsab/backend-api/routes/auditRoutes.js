const express = require('express');
const auditController = require('../controllers/auditController');

const router = express.Router();

// Route pour cr�er un audit
router.post('/', auditController.createAudit);

// Route pour obtenir la liste des audits
router.get('/', auditController.getAudits);

module.exports = router;